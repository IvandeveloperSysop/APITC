<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;
use Carbon\Carbon;


class DatabaseSeeder extends Seeder
{
    /**
     * Seed the application's database.
     *
     * @return void
     */
    public function run()
    {
        // \App\Models\User::factory(10)->create();
        DB::table('status_catalog')->insert([
            ['id' => 0,'name' => 'Cancelado', 'table' => 'tickets'],
            ['id' => 1,'name' => 'Aprobado', 'table' => 'tickets'],
            ['id' => 2,'name' => 'Revisando', 'table' => 'tickets'],
            ['id' => 3,'name' => 'revisando', 'table' => 'refers'],
            ['id' => 4,'name' => 'Cancelado', 'table' => 'refers'],
            ['id' => 5,'name' => 'Aprobado', 'table' => 'refers'],
            ['id' => 6,'name' => 'Aprobado', 'table' => 'extraPoints'],
            ['id' => 7,'name' => 'Cancelado', 'table' => 'app_share'],
            ['id' => 8,'name' => 'Aprobado', 'table' => 'app_share'],
            ['id' => 9,'name' => 'Revisando', 'table' => 'app_share'],
            ['id' => 10,'name' => 'Cancelado', 'table' => 'trivia_score'],
            ['id' => 11,'name' => 'Aprobado', 'table' => 'trivia_score'],
            ['id' => 12,'name' => 'Pendiente', 'table' => 'trivia_score'],
            ['id' => 13,'name' => 'Revisando', 'table' => 'trivia_score'],
            ['id' => 14,'name' => 'Activo', 'table' => 'trivia_questions'],
            ['id' => 15,'name' => 'Inactivo', 'table' => 'trivia_questions'],
            ['id' => 16,'name' => 'Correcta', 'table' => 'trivia_answers'],
            ['id' => 17,'name' => 'Incorrecta', 'table' => 'trivia_answers'],
            ['id' => 18,'name' => 'Activo', 'table' => 'users'],
            ['id' => 19,'name' => 'Inactivo', 'table' => 'users'],
        ]);

        DB::table('type_catalog')->insert([
            ['name' => 'refer', 'created_at' => Carbon::now() , 'updated_at' => Carbon::now()],
            ['name' => 'miniGames', 'created_at' => Carbon::now() , 'updated_at' => Carbon::now()],
            ['name' => 'app_share', 'created_at' => Carbon::now() , 'updated_at' => Carbon::now()],
        ]);

        ###
            // for ($i=0; $i < 10; $i++) { 
            //     # code...
            //     DB::table('tickets')->insert([
            //         ['id_user'=> '1',
            //         'file_url'=> 'ghkghihih',
            //         'date_ticket'=> Carbon::now(),
            //         'imagestr'=> 'opklñjklñjk',
            //         'period_id' => 1,
            //         'amount'=> 200,
            //         'points'=> 20,
            //         'count'=> 10,
            //         'status'=> 2,
            //         'created_at'=> Carbon::now(),
            //         'updated_at'=> Carbon::now()],
            //     ]);
            // }
        ###

        DB::table('periods')->insert([
            ['promo_id' => 1, 'inicial_date' => '2021-03-01 00:00:00', 'final_date' => '2021-03-15 23:59:59'],
            ['promo_id' => 1, 'inicial_date' => '2021-03-16 00:00:00', 'final_date' => '2021-03-31 23:59:59'],
            ['promo_id' => 1, 'inicial_date' => '2021-04-01 00:00:00', 'final_date' => '2021-04-15 23:59:59'],
            ['promo_id' => 1, 'inicial_date' => '2021-04-16 00:00:00', 'final_date' => '2021-04-30 23:59:59'],
        ]);
        
        DB::table('presentation')->insert([
            ['name' => 'Rollo grande', 'promo_id' => 1, 'pointValue' => 3],
            ['name' => 'Rollo mediano', 'promo_id' => 1, 'pointValue' => 4],
            ['name' => 'Rollo chico', 'promo_id' => 1, 'pointValue' => 5],
            ['name' => 'Rollo premium', 'promo_id' => 1, 'pointValue' => 6],
            ['name' => 'Rollo golden', 'promo_id' => 1, 'pointValue' => 6],
        ]);

        DB::table('promo')->insert([
            ['name' => 'Corre con agua', 'created_at' => Carbon::now() , 'updated_at' => Carbon::now()],
        ]);

        // DB::table('stores')->insert([
        //     ['name' => 'HEB', 'created_at' => Carbon::now() , 'updated_at' => Carbon::now()],
        //     ['name' => 'WALMART', 'created_at' => Carbon::now() , 'updated_at' => Carbon::now()],
        //     ['name' => 'OXXO', 'created_at' => Carbon::now() , 'updated_at' => Carbon::now()],
        //     ['name' => 'SEVEN', 'created_at' => Carbon::now() , 'updated_at' => Carbon::now()],
        //     ['name' => 'FARMACIAS GUADALAJARA', 'created_at' => Carbon::now() , 'updated_at' => Carbon::now()],
        // ]);

        // DB::table('cities')->insert([
        //     ['name' => 'Nuevo León', 'created_at' => Carbon::now() , 'updated_at' => Carbon::now()],
        //     ['name' => 'Jalisco', 'created_at' => Carbon::now() , 'updated_at' => Carbon::now()],
        //     ['name' => 'Coahuila', 'created_at' => Carbon::now() , 'updated_at' => Carbon::now()],
        //     ['name' => 'Durango', 'created_at' => Carbon::now() , 'updated_at' => Carbon::now()],
        //     ['name' => 'CDMX', 'created_at' => Carbon::now() , 'updated_at' => Carbon::now()],
        //     ['name' => 'Chiuhuahua', 'created_at' => Carbon::now() , 'updated_at' => Carbon::now()],
        //     ['name' => 'San Luis', 'created_at' => Carbon::now() , 'updated_at' => Carbon::now()],
        // ]);

    }
}
