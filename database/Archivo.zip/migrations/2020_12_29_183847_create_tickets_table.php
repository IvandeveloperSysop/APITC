<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateTicketsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('tickets', function (Blueprint $table) {
            $table->id();
            $table->integer('id_user');
            $table->integer('period_id');
            $table->string('numTicket')->nullable();
            $table->string('file_url');
            $table->date('date_ticket');
            $table->longText('imagestr');
            $table->longText('comment')->nullable();
            $table->integer('products')->nullable();
            $table->integer('amount')->nullable();
            $table->integer('points');
            $table->string('city_id');
            $table->integer('store_id');
            $table->integer('status');
            $table->integer('validate');
            $table->integer('id_admin')->nullable();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('tickets');
    }
}
